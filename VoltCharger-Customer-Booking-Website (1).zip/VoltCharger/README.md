# VoltCharger customer booking website

A clean, customer-first EV charger discovery and booking prototype.

- No hero section or promotional banner.
- No login or customer account required.
- Search by area, filter AC/DC chargers, view charger power, connector and display price.
- Select charger, date, start time and duration; submit booking request with name and mobile number.
- Interactive OpenStreetMap with sample Hyderabad station pins.
- No payment methods, checkout, wallets, refunds, commissions or payouts.

## Run
Open `index.html` in a browser, or run `python -m http.server 8000` in this folder and visit `http://localhost:8000`.

## Prototype limitation
Sample station details are illustrative. Booking requests are stored in this browser's localStorage only. To receive real bookings from customers on different devices, connect a backend/database and operator notification service. Enforce overlapping-booking prevention on the server/database before going live. Replace sample station addresses, availability and map coordinates with verified live data.
